module.exports = {
	menu: "   
┏━━━━━━━𝘽𝙀𝙈 𝙑𝙄𝙉𝘿𝙊━━━━━━━                  
┃
┣➥♠️𝐄𝐑𝐄𝐍 𝐁𝐎𝐓♠️
┣➥𝗗𝗢𝗡𝗢: 𝗚𝗔𝗔𝗥𝗔𝗭𝗜𝗡𝗛𝗢 愛
┣➥𝗦𝗧𝗔𝗧𝗨𝗦: 𝗢𝗡 ✅
┣➥𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗥 𝗘𝗠 𝗚𝗥𝗨𝗣𝗢 𝟭𝟬,𝟬𝟬💵
┣➥𝗔𝗗𝗤𝗨𝗜𝗥𝗜𝗥: wa.me/5596984081026
┣━━━━━━━━━━━━━━━━━━━━━
┣➥💎𝗟𝗜𝗦𝗧𝗔 𝗗𝗘 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦💎
┃
┣➥*!sticker [converte imagem em figurinha]*
┃
┣➥*!wallpaper [nome]*
┃
┣➥*!wallpaper2*
┃
┣➥*!wallpaper3*
┃
┣➥*!anime [nome]*
┃
┣➥*!anime2*
┃
┣➥*!hentai*
┃
┣➥*!image [texto]*: Envia foto do que foi pesquisado
┃
┣➥*!loli*
┃
┣➥*!neko*
┃
┣➥*!séries*
┃
┣➥*!filmes*
┃
┣➥*!Eren [a frase]*
┃
┣➥*!pornhub [pt1] | [pt2]*
┃
┣➥*!link [nome do pornô]*: Envia oque foi pesquisado
┃
┣➥*!letra*: Envia letra da música que foi pesquisada 
┃
┣➥*!trap*: Envia uma foto de trap
┃
┣➥*!cat*: Envia fotos de gatos
┃
┣➥*!dog*: Envia fotos de cachorros 
┃
┣➥*!luz texto*
┃
┣➥*!black texto*
┃
┣➥*!god texto
┃
┣➥*!trovão texto*
┃
┣➥*!matrix texto*
┃
┣➥*!3d texto*
┃
┣➥*!waifu*
┃
┣➥*!kiss*
┃
┣➥*!map*
┃
┣➥*!ip [o ip]*
┃
┣➥*!cep [o cep]*
┃
┣➥*!cnpj [o CNPJ]*
┃
┣➥*!geradorcpf*
┃
┣━━━━━━━━━━━━━━━━━━━━━
┣➥⚡𝗦𝗨𝗣𝗢𝗥𝗧𝗘⚡
┃
┣➥wa.me/5596984081026
┣━━━━━━━━━━━━━━━━━━━━━
┃   
┃  ║▌│█║▌│ █║▌│█│║▌║ 
┃  ║▌│█║▌│ █║▌│█│║▌║
┃
┃ Copyright © 𝐆𝐀𝐀𝐑𝐀𝐙𝐈𝐍𝐇𝐎 愛 2021
┃       
┗━━━━━━━━━━━━━━━━━━━━━"
}
